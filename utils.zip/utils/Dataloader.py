import os
from PIL import Image
import numpy as np
import random
import torch
from torchvision import transforms
from torch.utils import data
from torch.utils.data import Dataset


class MBRSDataset(Dataset):  # 定义了一个名为 MBRSDataset 的类，它继承自 Dataset 类。

	def __init__(self, path, H, W):  # MBRSDataset类的构造函数（初始化方法），它接受三个参数
		super(MBRSDataset, self).__init__()  # 调用了父类Dataset的构造函数，以确保正确地初始化父类。
		self.H = H  # 将传入的H和W参数分别赋值给类的实例变量self.H 和 self.W，用于存储图像的高度和宽度。
		self.W = W
		self.path = path
		self.list = os.listdir(path)  # 使用os.listdir函数获取self.path指定路径下的所有文件名，并将它们存储在self.list 中。
		self.transform = transforms.Compose([   # 创建一个 transforms.Compose 对象，用于组合一系列的图像变换操作。
			transforms.Resize((int(self.H * 1.1), int(self.W * 1.1))), # 添加了一个transforms.Resize变换，将图像大小调整为原始高度和宽度的1.1倍。
			transforms.RandomCrop((self.H, self.W)),  # 添加了一个transforms.RandomCrop变换，从调整大小后的图像中随机裁剪出原始高度和宽度的区域。
			transforms.ToTensor(),  # 码添加了一个transforms.ToTensor变换，将裁剪后的图像转换为PyTorch张量
			transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]) # 添加了一个 transforms.Normalize变换，对图像的每个通道进行标准化处理，均值为0.5，标准差为0.5。
		])




	def transform_image(self, image):

		# ignore
		if image.size[0] < self.W / 2 and image.size[1] < self.H / 2:  # 检查图像的宽度和高度是否都小于类属性 self.W 和 self.H 的一半
			return None
		if image.size[0] < image.size[1] / 2 or image.size[1] < image.size[0] / 2: # 这行代码检查图像的宽度是否小于高度的一半，意味着图像的宽高比不符合要求
			return None

		# Augment, ToTensor and Normalize
		image = self.transform(image)  # 这行代码调用了另一个方法 self.transform，传入图像作为参数

		return image

	def __getitem__(self, index):  # 定义了当对象通过索引访问时的行为，用来加载和转换图像数据。

		while True:  # 创建一个无限循环，直到找到有效的图像数据
			image = Image.open(os.path.join(self.path, self.list[index])).convert("RGB") # 使用PIL库打开图像文件（文件，名称）将图像转换为RGB模式
			image = self.transform_image(image)  # 应用一个转换函数self.transform_image来处理图像
			if image is not None: # 如果转换后的图像不为空（即转换成功），则返回这个图像
				return image
			# print("dataloader : skip index", index)
			index += 1  # 如果图像为空（可能是文件损坏或其他原因导致无法加载），则索引增加1，尝试加载下一张图像。

	def __len__(self): # 这个方法返回对象的长度，即self.list列表的长度。这个方法用于确定数据集的大小，从而可以正确地进行迭代
		return len(self.list)
