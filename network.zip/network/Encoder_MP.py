from network import *
import torch
import torch.nn as nn
import numpy as np
from network.blocks.SERes2Net import SERes2Net
from network.blocks.SENet import SENet


class Encoder_MP(nn.Module):
    '''
    Insert a watermark into an image
    '''

    def __init__(self, H, W, message_length, blocks=4, channels=64):
        super(Encoder_MP, self).__init__()
        self.H = H
        self.W = W

        message_convT_blocks = int(
            np.log2(H // int(np.sqrt(message_length))))  # message_convT_blocks计算的是输入数据的高度或宽度与输入数据长度的平方根的比值的以2为底的对数的整数部分
        message_se_blocks = max(blocks - message_convT_blocks,
                                1)  # message_se_blocks计算的是，在分配了一定数量的块给上采样网络之后，还剩下多少个块可以用于SE网络

        self.image_pre_layer = ConvBNRelu(3, channels)
        self.image_first_layer = SERes2Net(channels, channels, blocks=blocks)
        self.image_first_layer1 = nn.Sequential(
            ConvBNRelu(channels, channels),
            nn.Softmax(dim=1),
        )

        self.message_pre_layer = nn.Sequential(
            ConvBNRelu(1, channels),  # 卷积以改变通道数
            ExpandNet(channels, channels, blocks=message_convT_blocks),  # 4个上采样
            SERes2Net(channels, channels, blocks=message_se_blocks),  # 使用4个SE块
        )

        self.message_pre_layer1 = ConvBNRelu(2 * channels, channels)

        self.message_first_layer = SERes2Net(channels, channels, blocks=blocks)

        self.after_concat_layer = ConvBNRelu(channels, channels)

        self.final_layer = nn.Conv2d(channels + 3, 3, kernel_size=1)

    def forward(self, image, message):
        # first Conv part of Encoder
        image_pre = self.image_pre_layer(image)
        intermediate1 = self.image_first_layer(image_pre)
        feature_mask = (self.image_first_layer1(intermediate1)) * 64

        # Message Processor
        size = int(np.sqrt(message.shape[1]))
        message_image = message.view(-1, 1, size, size)
        message_pre = self.message_pre_layer(message_image)
        concat0 = torch.cat([image_pre, message_pre], dim=1)
        message_pre1 = self.message_pre_layer1(concat0)
        intermediate2 = self.message_first_layer(message_pre1)

        # concatenate
        # concat1 = torch.cat([feature_mask, intermediate2], dim=1)
        feature = intermediate2 * feature_mask
        # feature = intermediate2

        # second Conv part of Encoder
        intermediate3 = self.after_concat_layer(feature)

        # skip connection
        concat2 = torch.cat([intermediate3, image], dim=1)

        # last Conv part of Encoder
        output = self.final_layer(concat2)

        # Add residual connection
        output = output + image  # 残差连接：逐元素相加

        return output

class Encoder_MP_Diffusion(nn.Module):
	'''
	Insert a watermark into an image
	'''

	def __init__(self, H, W, message_length, blocks=4, channels=64, diffusion_length=256):
		super(Encoder_MP_Diffusion, self).__init__()
		self.H = H
		self.W = W

		self.diffusion_length = diffusion_length
		self.diffusion_size = int(diffusion_length ** 0.5)

		self.image_pre_layer = ConvBNRelu(3, channels)
		self.image_first_layer = SERes2Net(channels, channels, blocks=blocks)

		self.message_duplicate_layer = nn.Linear(message_length, self.diffusion_length)
		self.message_pre_layer_0 = ConvBNRelu(1, channels)
		self.message_pre_layer_1 = ExpandNet(channels, channels, blocks=3)
		self.message_pre_layer_2 = SERes2Net(channels, channels, blocks=1)
		self.message_first_layer = SERes2Net(channels, channels, blocks=blocks)

		self.after_concat_layer = ConvBNRelu(2 * channels, channels)

		self.final_layer = nn.Conv2d(channels + 3, 3, kernel_size=1)

	def forward(self, image, message):
		# first Conv part of Encoder
		image_pre = self.image_pre_layer(image)
		intermediate1 = self.image_first_layer(image_pre)

		# Message Processor (with diffusion)
		message_duplicate = self.message_duplicate_layer(message)
		message_image = message_duplicate.view(-1, 1, self.diffusion_size, self.diffusion_size)
		message_pre_0 = self.message_pre_layer_0(message_image)
		message_pre_1 = self.message_pre_layer_1(message_pre_0)
		message_pre_2 = self.message_pre_layer_2(message_pre_1)
		intermediate2 = self.message_first_layer(message_pre_2)

		# concatenate
		concat1 = torch.cat([intermediate1, intermediate2], dim=1)

		# second Conv part of Encoder
		intermediate3 = self.after_concat_layer(concat1)

		# skip connection
		concat2 = torch.cat([intermediate3, image], dim=1)

		# last Conv part of Network
		output = self.final_layer(concat2)

		return output


# 假设我们有以下参数
H = 128  # 图像高度
W = 128  # 图像宽度
message_length = 64  # 消息长度
blocks = 4  # 块的数量
channels = 64  # 通道数量
#diffusion_length = 256  # 扩散长度
encoder = Encoder_MP(H, W, message_length, blocks, channels,)

# 假设我们有一个随机生成的图像和一个随机生成的消息
# 图像大小为 (batch_size, channels, H, W)
image = torch.randn(1, 3, 128, 128)
# 消息大小为 (batch_size, message_length)
message = torch.randn(1, 64)

# 使用 forward 方法将消息嵌入到图像中
watermarked_image = encoder(image, message)

# 输出嵌入水印后的图像
print(watermarked_image.shape)