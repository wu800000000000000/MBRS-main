from network import *
import torch.nn as nn
import numpy as np
from network.blocks.SERes2Net import SERes2Net_decoder
from network.blocks.SERes2Net import SERes2Net
from network.blocks.MSFFMSE import MSFFMSE_decoder
from network.blocks.MobileNet import MobileNet_decoder
from network.blocks.MobileNet import MobileNet


class Decoder(nn.Module):
	'''
	Decode the encoded image and get message #解码编码后的图像并获取消息
	'''

	def __init__(self, H, W, message_length, blocks=4, channels=64):
		super(Decoder, self).__init__()

		stride_blocks = int(np.log2(H // int(np.sqrt(message_length))))  # 计算步幅块的数量，这取决于图像的高度和消息长度的平方根
		keep_blocks = max(blocks - stride_blocks, 0)  # 计算保留块的数量，这是总块数减去步幅块的数量

		self.first_layers = nn.Sequential(  # 定义解码器的第一部分层，包括卷积、批量归一化和ReLU激活函数
			ConvBNRelu(3, channels),
			SERes2Net_decoder(channels, channels, blocks=stride_blocks + 1),
			ConvBNRelu(channels * (2 ** stride_blocks), channels),  # 通道数乘以2的stride_blocks次方
		)
		self.keep_layers = SERes2Net(channels, channels, blocks=keep_blocks)  # 定义解码器的保留层，这是SENet块，用于保持特征

		self.final_layer = ConvBNRelu(channels, 1)  # 定义解码器的最后一层，将通道数从channels减少到1

	def forward(self, noised_image):
		x = self.first_layers(noised_image)
		x = self.keep_layers(x)
		x = self.final_layer(x)
		x = x.view(x.shape[0], -1)
		return x

	# 新增：统计参数数量
	def count_parameters(self, trainable_only=False):
		"""
		统计模型参数数量
		Args:
			trainable_only: 是否只统计可训练参数（默认False，统计所有参数）
		Returns:
			total_params: 参数总数
		"""
		if trainable_only:
			total_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
		else:
			total_params = sum(p.numel() for p in self.parameters())
		return total_params

	# 新增：打印参数详细信息
	def print_parameter_info(self):
		"""打印模型参数统计信息"""
		total_params = self.count_parameters()
		trainable_params = self.count_parameters(trainable_only=True)
		non_trainable_params = total_params - trainable_params

		# 格式化输出参数数量（带千分位分隔符）
		print(f"=== Decoder 参数统计 ===")
		print(f"总参数数量: {total_params:,}")
		print(f"可训练参数: {trainable_params:,}")
		print(f"不可训练参数: {non_trainable_params:,}")


class Decoder_Diffusion(nn.Module):
	'''
	Decode the encoded image and get message
	'''

	def __init__(self, H, W, message_length, blocks=4, channels=64, diffusion_length=256):
		super(Decoder_Diffusion, self).__init__()

		stride_blocks = int(np.log2(H // int(np.sqrt(diffusion_length))))

		self.diffusion_length = diffusion_length
		self.diffusion_size = int(self.diffusion_length ** 0.5)

		self.first_layers = nn.Sequential(
			ConvBNRelu(3, channels),
			SERes2Net_decoder(channels, channels, blocks=stride_blocks + 1),
			ConvBNRelu(channels * (2 ** stride_blocks), channels),
		)
		self.keep_layers = SERes2Net(channels, channels, blocks=1)

		self.final_layer = ConvBNRelu(channels, 1)

		self.message_layer = nn.Linear(self.diffusion_length, message_length)

	def forward(self, noised_image):
		x = self.first_layers(noised_image)
		x = self.keep_layers(x)
		x = self.final_layer(x)
		x = x.view(x.shape[0], -1)

		x = self.message_layer(x)
		return x

	# 新增：统计参数数量
	def count_parameters(self, trainable_only=False):
		"""
		统计模型参数数量
		Args:
			trainable_only: 是否只统计可训练参数（默认False，统计所有参数）
		Returns:
			total_params: 参数总数
		"""
		if trainable_only:
			total_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
		else:
			total_params = sum(p.numel() for p in self.parameters())
		return total_params

	# 新增：打印参数详细信息
	def print_parameter_info(self):
		"""打印模型参数统计信息"""
		total_params = self.count_parameters()
		trainable_params = self.count_parameters(trainable_only=True)
		non_trainable_params = total_params - trainable_params

		# 格式化输出参数数量（带千分位分隔符）
		print(f"=== Decoder_Diffusion 参数统计 ===")
		print(f"总参数数量: {total_params:,}")
		print(f"可训练参数: {trainable_params:,}")
		print(f"不可训练参数: {non_trainable_params:,}")


# 示例调用方式（可根据需要选择是否保留）
if __name__ == "__main__":
	# 初始化模型并查看参数
	decoder = Decoder(H=128, W=128, message_length=64)
	decoder.print_parameter_info()

	decoder_diff = Decoder_Diffusion(H=128, W=128, message_length=64)
	decoder_diff.print_parameter_info()

	# 单独获取参数数量
	#print(f"\nDecoder 可训练参数数量: {decoder.count_parameters(trainable_only=True):,}")
	print(f"Decoder_Diffusion 总参数数量: {decoder_diff.count_parameters():,}")
