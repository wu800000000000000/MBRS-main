import torch.nn as nn
import numpy as np  # 导入numpy模块
import torch
from kornia.geometry.transform import affine  # 确保导入 affine 函数
import random  # 导入随机模块
import math  # 导入math模块




def Light_Distortion(c, image_and_cover):  # 光照失真
    mask = np.zeros((image_and_cover.shape))
    mask_2d = np.zeros((image_and_cover.shape[2], image_and_cover.shape[3]))
    a = 0.7 + np.random.rand(1) * 0.2
    b = 1.1 + np.random.rand(1) * 0.2
    if c == 0:
        direction = np.random.randint(1, 5)
        for i in range(image_and_cover.shape[2]):
            mask_2d[i, :] = -((b - a) / (mask.shape[2] - 1)) * (i - mask.shape[3]) + a
        if direction == 1:
            O = mask_2d
        elif direction == 2:
            O = np.rot90(mask_2d, 1)
        elif direction == 3:
            O = np.rot90(mask_2d, 1)
        elif direction == 4:
            O = np.rot90(mask_2d, 1)
        for batch in range(image_and_cover.shape[0]):
            for channel in range(image_and_cover.shape[1]):
                mask[batch, channel, :, :] = mask_2d
    else:
        x = np.random.randint(0, mask.shape[2])
        y = np.random.randint(0, mask.shape[3])
        max_len = np.max([np.sqrt(x ** 2 + y ** 2), np.sqrt((x - 255) ** 2 + y ** 2),
                          np.sqrt(x ** 2 + (y - 255) ** 2), np.sqrt((x - 255) ** 2 + (y - 255) ** 2)])
        for i in range(mask.shape[2]):
            for j in range(mask.shape[3]):
                mask[:, :, i, j] = np.sqrt((i - x) ** 2 + (j - y) ** 2) / max_len * (a - b) + b
        O = mask
    return O
