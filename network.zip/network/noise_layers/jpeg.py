import os
import numpy as np
import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
import random, string


class JpegTest(nn.Module): #这个类是用于测试JPEG压缩的噪声层
	def __init__(self, Q, subsample=2, path="temp/"):
		super(JpegTest, self).__init__()
		self.Q = Q
		self.subsample = subsample
		self.path = path
		if not os.path.exists(path): os.mkdir(path)

	def get_path(self):
		return self.path + ''.join(random.sample(string.ascii_letters + string.digits, 16)) + ".jpg"

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover

		shape = image.shape
		noised_image = torch.zeros_like(image)

		for i in range(shape[0]):
			single_image = ((image[i].clamp(-1, 1).permute(1, 2, 0) + 1) / 2 * 255).to('cpu', torch.uint8).numpy()
			im = Image.fromarray(single_image)

			file = self.get_path()
			while os.path.exists(file):
				file = self.get_path()
			im.save(file, format="JPEG", quality=self.Q, subsampling=self.subsample)
			jpeg = np.array(Image.open(file), dtype=np.uint8)
			os.remove(file)

			transform = transforms.Compose([
				transforms.ToTensor(),
				transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
			])

			noised_image[i] = transform(jpeg).unsqueeze(0).to(image.device)

		return noised_image


class JpegBasic(nn.Module): #这个类提供了JPEG压缩的基本功能
	def __init__(self):
		super(JpegBasic, self).__init__()


	def std_quantization(self, image_yuv_dct, scale_factor, round_func=torch.round):  #对图像进行标准化量化处理（self,图像yuv_dct,缩放因子，四舍五入函数）

		luminance_quant_tbl = (torch.tensor([   #标准亮度量化表
			[16, 11, 10, 16, 24, 40, 51, 61],
			[12, 12, 14, 19, 26, 58, 60, 55],
			[14, 13, 16, 24, 40, 57, 69, 56],
			[14, 17, 22, 29, 51, 87, 80, 62],
			[18, 22, 37, 56, 68, 109, 103, 77],
			[24, 35, 55, 64, 81, 104, 113, 92],
			[49, 64, 78, 87, 103, 121, 120, 101],
			[72, 92, 95, 98, 112, 100, 103, 99]
		], dtype=torch.float) * scale_factor).round().to(image_yuv_dct.device).clamp(min=1).repeat(  #创建了一个浮点数张量，将其乘以一个缩放因子，然后四舍五入，转移到指定设备，限制最小值为1
			image_yuv_dct.shape[2] // 8, image_yuv_dct.shape[3] // 8)  #并在两个维度上重复张量，以适应 image_yuv_dct 的形状

		chrominance_quant_tbl = (torch.tensor([   #标准色度量化表
			[17, 18, 24, 47, 99, 99, 99, 99],
			[18, 21, 26, 66, 99, 99, 99, 99],
			[24, 26, 56, 99, 99, 99, 99, 99],
			[47, 66, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99]
		], dtype=torch.float) * scale_factor).round().to(image_yuv_dct.device).clamp(min=1).repeat(
			image_yuv_dct.shape[2] // 8, image_yuv_dct.shape[3] // 8)

		q_image_yuv_dct = image_yuv_dct.clone() #创建 image_yuv_dct 的一个副本，赋值给 q_image_yuv_dct，以便在不改变原始图像数据的情况下进行量化处理。
		q_image_yuv_dct[:, :1, :, :] = image_yuv_dct[:, :1, :, :] / luminance_quant_tbl #将 q_image_yuv_dct 的亮度分量（Y分量）除以亮度量化表 luminance_quant_tbl，进行量化处理。
		q_image_yuv_dct[:, 1:, :, :] = image_yuv_dct[:, 1:, :, :] / chrominance_quant_tbl #色度
		q_image_yuv_dct_round = round_func(q_image_yuv_dct) #对量化后的图像数据 q_image_yuv_dct 应用四舍五入函数 round_func，得到最终的量化图像数据 q_image_yuv_dct_round。
		return q_image_yuv_dct_round

	def std_reverse_quantization(self, q_image_yuv_dct, scale_factor): #反量化处理

		luminance_quant_tbl = (torch.tensor([
			[16, 11, 10, 16, 24, 40, 51, 61],
			[12, 12, 14, 19, 26, 58, 60, 55],
			[14, 13, 16, 24, 40, 57, 69, 56],
			[14, 17, 22, 29, 51, 87, 80, 62],
			[18, 22, 37, 56, 68, 109, 103, 77],
			[24, 35, 55, 64, 81, 104, 113, 92],
			[49, 64, 78, 87, 103, 121, 120, 101],
			[72, 92, 95, 98, 112, 100, 103, 99]
		], dtype=torch.float) * scale_factor).round().to(q_image_yuv_dct.device).clamp(min=1).repeat(
			q_image_yuv_dct.shape[2] // 8, q_image_yuv_dct.shape[3] // 8)

		chrominance_quant_tbl = (torch.tensor([
			[17, 18, 24, 47, 99, 99, 99, 99],
			[18, 21, 26, 66, 99, 99, 99, 99],
			[24, 26, 56, 99, 99, 99, 99, 99],
			[47, 66, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99],
			[99, 99, 99, 99, 99, 99, 99, 99]
		], dtype=torch.float) * scale_factor).round().to(q_image_yuv_dct.device).clamp(min=1).repeat(
			q_image_yuv_dct.shape[2] // 8, q_image_yuv_dct.shape[3] // 8)

		image_yuv_dct = q_image_yuv_dct.clone()
		image_yuv_dct[:, :1, :, :] = q_image_yuv_dct[:, :1, :, :] * luminance_quant_tbl
		image_yuv_dct[:, 1:, :, :] = q_image_yuv_dct[:, 1:, :, :] * chrominance_quant_tbl
		return image_yuv_dct

	def dct(self, image):   #对图像进行离散余弦变换（DCT）
		# coff for dct and idct
		coff = torch.zeros((8, 8), dtype=torch.float).to(image.device)  #定义了一个8x8的张量，用于存储DCT变换的系数
		coff[0, :] = 1 * np.sqrt(1 / 8)  #设置第一行的系数
		for i in range(1, 8):   #循环计算并设置其他行的DCT系数
			for j in range(8):
				coff[i, j] = np.cos(np.pi * i * (2 * j + 1) / (2 * 8)) * np.sqrt(2 / 8)

		split_num = image.shape[2] // 8  #计算图像在宽度方向上可以分割成多少个8像素宽的块。
		image_dct = torch.cat(torch.cat(image.split(8, 2), 0).split(8, 3), 0) #将图像分割成8x8的块
		image_dct = torch.matmul(coff, image_dct)  #对每个8x8块应用DCT变换
		image_dct = torch.matmul(image_dct, coff.permute(1, 0))  #应用DCT变换的第二阶段。
		image_dct = torch.cat(torch.cat(image_dct.chunk(split_num, 0), 3).chunk(split_num, 0), 2)  #将变换后的块重新组合成完整的图像。

		return image_dct

	def idct(self, image_dct):  #对图像进行离散余弦反变换（IDCT）
		# coff for dct and idct
		coff = torch.zeros((8, 8), dtype=torch.float).to(image_dct.device)
		coff[0, :] = 1 * np.sqrt(1 / 8)
		for i in range(1, 8):
			for j in range(8):
				coff[i, j] = np.cos(np.pi * i * (2 * j + 1) / (2 * 8)) * np.sqrt(2 / 8)

		split_num = image_dct.shape[2] // 8
		image = torch.cat(torch.cat(image_dct.split(8, 2), 0).split(8, 3), 0)
		image = torch.matmul(coff.permute(1, 0), image)
		image = torch.matmul(image, coff)
		image = torch.cat(torch.cat(image.chunk(split_num, 0), 3).chunk(split_num, 0), 2)

		return image

	def rgb2yuv(self, image_rgb):  #定义了一个名为rgb2yuv的函数，它用于将RGB格式的图像转换为YUV格式
		image_yuv = torch.empty_like(image_rgb)
		image_yuv[:, 0:1, :, :] = 0.299 * image_rgb[:, 0:1, :, :] \
								  + 0.587 * image_rgb[:, 1:2, :, :] + 0.114 * image_rgb[:, 2:3, :, :]
		image_yuv[:, 1:2, :, :] = -0.1687 * image_rgb[:, 0:1, :, :] \
								  - 0.3313 * image_rgb[:, 1:2, :, :] + 0.5 * image_rgb[:, 2:3, :, :]
		image_yuv[:, 2:3, :, :] = 0.5 * image_rgb[:, 0:1, :, :] \
								  - 0.4187 * image_rgb[:, 1:2, :, :] - 0.0813 * image_rgb[:, 2:3, :, :]
		return image_yuv

	def yuv2rgb(self, image_yuv):  #定义了一个名为yuv2rgb的函数，它用于将YUV格式的图像转换为RGB格式
		image_rgb = torch.empty_like(image_yuv)
		image_rgb[:, 0:1, :, :] = image_yuv[:, 0:1, :, :] + 1.40198758 * image_yuv[:, 2:3, :, :]
		image_rgb[:, 1:2, :, :] = image_yuv[:, 0:1, :, :] - 0.344113281 * image_yuv[:, 1:2, :, :] \
								  - 0.714103821 * image_yuv[:, 2:3, :, :]
		image_rgb[:, 2:3, :, :] = image_yuv[:, 0:1, :, :] + 1.77197812 * image_yuv[:, 1:2, :, :]
		return image_rgb

	def yuv_dct(self, image, subsample): #对图像进行YUV色彩空间转换、子采样、离散余弦变换（DCT）
		# clamp and convert from [-1,1] to [0,255]
		image = (image.clamp(-1, 1) + 1) * 255 / 2 #将图像数据限制在[-1,1]范围内，并转换到[0,255]范围

		# pad the image so that we can do dct on 8x8 blocks
		pad_height = (8 - image.shape[2] % 8) % 8  #对图像高度进行填充，以便能够对8x8块进行DCT
		pad_width = (8 - image.shape[3] % 8) % 8   #对图像宽度进行填充，以便能够对8x8块进行DCT
		image = nn.ZeroPad2d((0, pad_width, 0, pad_height))(image)  #使用PyTorch框架中的nn.ZeroPad2d函数对图像进行零填充操作

		# convert to yuv转换到YUV色彩空间
		image_yuv = self.rgb2yuv(image)

		assert image_yuv.shape[2] % 8 == 0
		assert image_yuv.shape[3] % 8 == 0

		# subsample 子采样
		image_subsample = self.subsampling(image_yuv, subsample)

		# apply dct 应用DCT
		image_dct = self.dct(image_subsample)

		return image_dct, pad_width, pad_height  #返回DCT结果，填充宽度和高度

	def idct_rgb(self, image_quantization, pad_width, pad_height): #对量化后的图像进行逆离散余弦变换（IDCT
		# apply inverse dct (idct)
		image_idct = self.idct(image_quantization)  #应用逆离散余弦变换（IDCT）

		# transform from yuv to to rgb
		image_ret_padded = self.yuv2rgb(image_idct)  #从YUV转换到RGB

		# un-pad 去除填充
		image_rgb = image_ret_padded[:, :, :image_ret_padded.shape[2] - pad_height,
					:image_ret_padded.shape[3] - pad_width].clone()

		return image_rgb * 2 / 255 - 1  #将图像数据值从[0,255]范围转换回[-1,1]范围

	def subsampling(self, image, subsample): #定义了一个名为 subsampling 的函数，它用于对图像进行子采样处理
		if subsample == 2:  #如果子采样率是2，则执行子采样操作
			split_num = image.shape[2] // 8  #计算图像可以被分成多少个8x8的块
			image_block = torch.cat(torch.cat(image.split(8, 2), 0).split(8, 3), 0)  #将图像分割成8x8的块
			for i in range(8):  #对每个块的U和V分量进行2:1的抽样
				if i % 2 == 1: image_block[:, 1:3, i, :] = image_block[:, 1:3, i - 1, :]
			for j in range(8):
				if j % 2 == 1: image_block[:, 1:3, :, j] = image_block[:, 1:3, :, j - 1]
			image = torch.cat(torch.cat(image_block.chunk(split_num, 0), 3).chunk(split_num, 0), 2) #将处理后的块重新组合成完整的图像
		return image  #返回子采样后的图像


class Jpeg(JpegBasic): #这个类继承自JpegBasic，并实现了完整的JPEG压缩流程
	def __init__(self, Q, subsample=0):
		super(Jpeg, self).__init__()

		# quantization table 量化表
		self.Q = Q
		self.scale_factor = 2 - self.Q * 0.02 if self.Q >= 50 else 50 / self.Q # 计算缩放因子，这个因子会根据Q值调整量化表的强度

		# subsample下采样
		self.subsample = subsample

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover

		# [-1,1] to [0,255], rgb2yuv, dct  # 将图像从[-1,1]范围映射到[0,255]，然后从RGB转换到YUV色彩空间，最后进行DCT变换
		image_dct, pad_width, pad_height = self.yuv_dct(image, self.subsample)

		# quantization 量化
		image_quantization = self.std_quantization(image_dct, self.scale_factor)

		# reverse quantization 反量化
		image_quantization = self.std_reverse_quantization(image_quantization, self.scale_factor)

		# idct, yuv2rgb, [0,255] to [-1,1]  进行IDCT变换，从YUV转换回RGB色彩空间，并将[0,255]范围映射回[-1,1]
		noised_image = self.idct_rgb(image_quantization, pad_width, pad_height)
		return noised_image.clamp(-1, 1)  #确保输出图像的值在[-1, 1]范围内


class JpegSS(JpegBasic): #这个类也继承自JpegBasic，但它在量化步骤中使用了一种特殊的舍入函数（round_ss）
	def __init__(self, Q, subsample=0):
		super(JpegSS, self).__init__()

		# quantization table量化表
		self.Q = Q
		self.scale_factor = 2 - self.Q * 0.02 if self.Q >= 50 else 50 / self.Q

		# subsample 下采样
		self.subsample = subsample

	def round_ss(self, x):   #定义了一个名为 round_ss 的函数，它接受一个参数 x
		cond = torch.tensor((torch.abs(x) < 0.5), dtype=torch.float).to(x.device) #如果 x 中的元素的绝对值小于0.5，则将其值设置为该元素的三次方（这会使得值更接近0）
		return cond * (x ** 3) + (1 - cond) * x  #则将其值设置为该元素的三次方（这会使得值更接近0），否则将元素的值设置为它本身

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover

		# [-1,1] to [0,255], rgb2yuv, dct
		image_dct, pad_width, pad_height = self.yuv_dct(image, self.subsample)

		# quantization
		image_quantization = self.std_quantization(image_dct, self.scale_factor, self.round_ss)

		# reverse quantization
		image_quantization = self.std_reverse_quantization(image_quantization, self.scale_factor)

		# idct, yuv2rgb, [0,255] to [-1,1]
		noised_image = self.idct_rgb(image_quantization, pad_width, pad_height)
		return noised_image.clamp(-1, 1)


class JpegMask(JpegBasic): #这个类同样继承自JpegBasic，它在DCT系数上应用了一个掩码（round_mask），这可能用于实现一种特殊的压缩策略
	def __init__(self, Q, subsample=0):
		super(JpegMask, self).__init__()

		# quantization table 量化表
		self.Q = Q
		self.scale_factor = 2 - self.Q * 0.02 if self.Q >= 50 else 50 / self.Q

		# subsample 子采样
		self.subsample = subsample

	def round_mask(self, x):
		mask = torch.zeros(1, 3, 8, 8).to(x.device)  #创建一个(1, 3, 8, 8)的遮罩张量，初始化为0
		mask[:, 0:1, :5, :5] = 1  #第一个通道（Y分量）设置遮罩的中心区域为1，这里假设遮罩是针对YUV中的Y分量（亮度）
		mask[:, 1:3, :3, :3] = 1  #第二三个通道（U和V分量）设置遮罩的U和V分量（色度）的中心区域为1
		mask = mask.repeat(1, 1, x.shape[2] // 8, x.shape[3] // 8)  #根据输入x的尺寸，重复遮罩以匹配x的形状
		return x * mask  #将遮罩应用到输入x上

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover

		# [-1,1] to [0,255], rgb2yuv, dct
		image_dct, pad_width, pad_height = self.yuv_dct(image, self.subsample) #将图像数据从[-1,1]范围转换到[0,255]范围，然后从RGB转换到YUV，最后进行DCT

		# mask
		image_mask = self.round_mask(image_dct)  #创建遮罩并应用到DCT变换后的图像上

		# idct, yuv2rgb, [0,255] to [-1,1]
		noised_image = self.idct_rgb(image_mask, pad_width, pad_height)  #进行逆DCT，从YUV转换回RGB，然后将图像数据从[0,255]范围转换回[-1,1]范围
		return noised_image.clamp(-1, 1)  #确保输出图像的数据在[-1,1]范围内
