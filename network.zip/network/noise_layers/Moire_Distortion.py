import torch
import numpy as np

def MoireGen(p_size, theta, center_x, center_y):
    z = np.zeros((p_size, p_size))
    for i in range(p_size):
        for j in range(p_size):
            z1 = 0.5 + 0.5 * np.cos(2 * np.pi * np.sqrt((i + 1 - center_x) ** 2 + (j + 1 - center_y) ** 2))
            z2 = 0.5 + 0.5 * np.cos(np.cos(theta / 180 * np.pi) * (j + 1) + np.sin(theta / 180 * np.pi) * (i + 1))
            z[i, j] = np.min([z1, z2])
    M = (z + 1) / 2
    return M

def Moire_Distortion(image_and_cover):
    # 检查 image_and_cover 是否为 PyTorch 张量
    if isinstance(image_and_cover, torch.Tensor):
        # 如果需要梯度，先分离出来
        if image_and_cover.requires_grad:
            image_and_cover = image_and_cover.detach()
        # 转换为 NumPy 数组
        image_and_cover = image_and_cover.numpy()
    elif isinstance(image_and_cover, list):
        # 将列表转换为 NumPy 数组
        image_and_cover = np.array(image_and_cover)
    else:
        raise TypeError("Unsupported type for image_and_cover")

    # 确保 image_and_cover 是一个 NumPy 数组
    Z = np.zeros(image_and_cover.shape)
    for i in range(3):
        theta = np.random.randint(0, 180)
        center_x = np.random.rand() * image_and_cover.shape[2]
        center_y = np.random.rand() * image_and_cover.shape[3]
        M = MoireGen(image_and_cover.shape[2], theta, center_x, center_y)
        Z[:, i, :, :] = M
    return Z