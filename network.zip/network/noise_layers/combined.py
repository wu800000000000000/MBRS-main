import torch.nn as nn
from network.noise_layers import get_random_int
from network.noise_layers import Identity



class Combined(nn.Module):    #定义Combined类，继承自PyTorch的nn.Module

	def __init__(self, list=None):  #初始化方法
		super(Combined, self).__init__()  #调用父类的初始化方法
		if list is None:
			list = [Identity()]  #如果传入的list为空，则默认使用一个Identity模型（即不做任何操作的模型）

		self.list = list  #如果list不为空，将传入的模型列表赋值给self.list。

	def forward(self, image_and_cover):
		id = get_random_int([0, len(self.list) - 1])  #随机选择一个索引，用于从self.list中选择一个模型
		return self.list[id](image_and_cover)  #返回被选中模型对输入image_and_cover的处理结果


