import torch.nn as nn
from kornia.filters import GaussianBlur2d


class GF(nn.Module):  # 高斯模糊

	def __init__(self, sigma, kernel=7):
		super(GF, self).__init__()
		self.gaussian_filter = GaussianBlur2d((kernel, kernel), (sigma, sigma)) # sigma是标准差（σ），表示高斯核的标准差

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover
		return self.gaussian_filter(image)

