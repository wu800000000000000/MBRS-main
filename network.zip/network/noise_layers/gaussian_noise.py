import numpy as np
import torch
import torch.nn as nn


class GN(nn.Module):  # 高斯噪声

	def __init__(self, var, mean=0):
		super(GN, self).__init__()
		self.var = var # 方差
		self.mean = mean # 均值

	def gaussian_noise(self, image, mean, var):
		noise = torch.Tensor(np.random.normal(mean, var ** 0.5, image.shape)).to(image.device)
		out = image + noise
		return out

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover
		return self.gaussian_noise(image, self.mean, self.var)
