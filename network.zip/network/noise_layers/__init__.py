import random


def get_random_float(float_range: [float]):  #函数的作用是在 [float_range[0], float_range[1]] 这个闭区间内生成一个随机浮点数并返回
	return random.random() * (float_range[1] - float_range[0]) + float_range[0]


def get_random_int(int_range: [int]):  #这个函数的作用是在 [int_range[0], int_range[1]] 这个闭区间内生成一个随机整数并返回
	return random.randint(int_range[0], int_range[1])


from network.noise_layers.identity import Identity
from network.noise_layers.crop import Crop, Cropout, Dropout
from network.noise_layers.gaussian_noise import GN
from network.noise_layers.middle_filter import MF
from network.noise_layers.gaussian_filter import GF
from network.noise_layers.salt_pepper_noise import SP
from network.noise_layers.jpeg import Jpeg, JpegSS, JpegMask, JpegTest
from network.noise_layers.combined import Combined
from network.noise_layers.Light_Distortion import Light_Distortion
from network.noise_layers.Moire_Distortion import Moire_Distortion