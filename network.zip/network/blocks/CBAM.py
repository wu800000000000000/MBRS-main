import torch
import torch.nn as nn
from network.blocks.SENet import SENet
from network.blocks.SERes2Net import SERes2Net


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), "kernel size must be 3 or 7"
        padding = 3 if kernel_size == 7 else 1

        # 空间注意力通过通道压缩+卷积实现
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 输入x维度: [batch, channels, height, width]

        # 通道维度压缩（平均池化+最大池化）
        avg_out = torch.mean(x, dim=1, keepdim=True)  # [B, 1, H, W]
        max_out, _ = torch.max(x, dim=1, keepdim=True)  # [B, 1, H, W]

        # 拼接通道统计信息
        combined = torch.cat([avg_out, max_out], dim=1)  # [B, 2, H, W]

        # 生成空间注意力权重图
        attention = self.conv(combined)  # [B, 1, H, W]
        attention_map = self.sigmoid(attention)

        return attention_map  # 输出权重图用于与原始特征相乘


# 完整CBAM模块示例（通道+空间注意力结合）
class CBAM(nn.Module):
    def __init__(self, channel, reduction=16, blocks=4, kernel_size=7):
        super().__init__()
       # self.ca = SERes2Net(channel, reduction)  # 通道注意力（需单独实现）
        self.sa = SpatialAttention(kernel_size)     # 本文空间注意力

    def forward(self, x):
       # x = self.ca(x) * x  # 先应用通道注意力
        x = self.sa(x) * x  # 再应用空间注意力
        return x