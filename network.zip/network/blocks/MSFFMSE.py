from network import *
import torch
import torch.nn as nn
import numpy as np

class MSFFMSEBlock(nn.Module):
    def __init__(self, in_channels, out_channels, scale, r, drop_rate):
        super(MSFFMSEBlock, self).__init__()
        self.scale = scale
        self.width = out_channels // scale
        self.downsample = None

        if in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=drop_rate, bias=False),
                nn.BatchNorm2d(out_channels)
            )

        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

        # 可分割的卷积层
        self.convs = nn.ModuleList()
        kernel_sizes = [3, 5, 7]  # 定义不同的卷积核大小
        for i in range(1, scale):  # 从 1 开始，因为第一个分支没有卷积操作
            padding = kernel_sizes[i - 1] // 2  # 根据卷积核大小计算padding
            self.convs.append(nn.Sequential(
                nn.Conv2d(self.width, self.width, kernel_size=kernel_sizes[i - 1], padding=padding, bias=False),
                nn.BatchNorm2d(self.width),
                nn.ReLU(inplace=True)
            ))

        # 最后一个卷积层
        self.conv3 = nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=drop_rate, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)

        # Squeeze-and-Excitation模块
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(out_channels, out_channels // r, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels // r, out_channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        identity = x

        # 第一个卷积层
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        # 可分割的卷积层
        spx = torch.split(out, self.width, 1)  # 将张量 out 按照维度 1（通道维度）分割成多个子张量
        out = spx[0]   # 第一个分支直接输出，没有卷积操作
        for i in range(1, self.scale):  # 从第二个分支开始
            sp = spx[i]  # 获取当前分支的子张量
            sp = self.convs[i - 1](sp)  # 应用对应的卷积操作
            out = torch.cat((out, sp), 1)  # 将结果拼接到输出张量中

        # 最后一个卷积层
        out = self.conv3(out)
        out = self.bn3(out)

        # Squeeze-and-Excitation模块
        scale = self.se(out)
        out = out * scale

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity  # 输入x与identity相加，用于实现残差连接
        out = self.relu(out)  # 对相加后的结果应用ReLU激活函数

        return out

class MSFFMSE(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="MSFFMSEBlock", r=8, scale=4, drop_rate=1):
        super(MSFFMSE, self).__init__()
        self.layers = nn.ModuleList()

        # 根据 block_type 动态创建层
        if block_type == "MSFFMSEBlock":
            block_class = MSFFMSEBlock
        else:
            raise ValueError(f"Unsupported block type: {block_type}")

        for _ in range(blocks):
            if _ == 0:
                self.layers.append(block_class(in_channels, out_channels, scale, r, drop_rate))
            else:
                self.layers.append(block_class(out_channels, out_channels, scale, r, drop_rate))

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x


class MSFFMSE_decoder(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="MSFFMSEBlock", r=8, scale=4, drop_rate=2):
        super(MSFFMSE_decoder, self).__init__()
        self.layers = nn.ModuleList()

        # 根据 block_type 动态创建层
        if block_type == "MSFFMSEBlock":
            block_class = MSFFMSEBlock
        else:
            raise ValueError(f"Unsupported block type: {block_type}")

        # 第一层
        self.layers.append(block_class(in_channels, out_channels, scale, r, 1))  # drop_rate 为 1
        for _ in range(1, blocks):
            # 每次循环创建两个块
            self.layers.append(block_class(out_channels, out_channels, scale, r, 1))  # drop_rate 为 1
            self.layers.append(block_class(out_channels, out_channels * drop_rate, scale, r, drop_rate))  # drop_rate 为指定值
            out_channels *= drop_rate  # 更新 out_channels

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
