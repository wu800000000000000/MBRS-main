import torch.nn as nn
import torch.nn.functional as F
import torch


# 定义独立的ECA模块，方便复用
class ECABlock(nn.Module):
    def __init__(self, kernel_size=3):
        super(ECABlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)  # [B, C, 1, 1]
        y = y.squeeze(-1).transpose(-1, -2)  # [B, 1, C]
        y = self.conv(y)  # [B, 1, C]
        y = y.transpose(-1, -2).unsqueeze(-1)  # [B, C, 1, 1]
        y = self.sigmoid(y)
        return x * y


class BottleneckBlock(nn.Module):
    def __init__(self, in_channels, out_channels, r, scale, drop_rate):
        super(BottleneckBlock, self).__init__()
        width = int(out_channels / scale)

        self.downsample = None
        if (in_channels != out_channels):
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1, padding=0,
                          stride=drop_rate, bias=False),
                nn.BatchNorm2d(out_channels)
            )

        self.conv1 = nn.Conv2d(in_channels, width, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(width)
        self.conv2 = nn.Conv2d(width, width, kernel_size=3, padding=1, stride=drop_rate, bias=False)
        self.bn2 = nn.BatchNorm2d(width)
        self.conv3 = nn.Conv2d(width, out_channels, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)

        # 使用独立的ECA模块
        self.eca = ECABlock()

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = F.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        # ECA注意力
        out = self.eca(out)

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity
        out = F.relu(out)
        return out


class SERes2NetBlock(nn.Module):
    def __init__(self, in_channels, out_channels, scale, r, drop_rate):
        super(SERes2NetBlock, self).__init__()
        self.scale = scale
        self.width = out_channels // scale
        self.downsample = None

        if in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=drop_rate, bias=False),
                nn.BatchNorm2d(out_channels)
            )

        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

        # 可分割的卷积层：深度可分离卷积 + 每个后面加ECA
        self.convs = nn.ModuleList()
        for i in range(scale - 1):
            self.convs.append(nn.Sequential(
                # Depthwise Convolution（深度卷积）
                nn.Conv2d(self.width, self.width, kernel_size=3, padding=1, groups=self.width, bias=False),
                nn.BatchNorm2d(self.width),
                nn.ReLU(inplace=True),
                # Pointwise Convolution（逐点卷积）
                nn.Conv2d(self.width, self.width, kernel_size=1, bias=False),
                nn.BatchNorm2d(self.width),
                nn.ReLU(inplace=True),
                # 在每个深度可分离卷积后面添加ECA
                ECABlock()
            ))




        # 最后一个卷积层
        self.conv3 = nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=drop_rate, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)

        # 使用独立的ECA模块
        self.eca = ECABlock()

    def forward(self, x):
        identity = x

        # 第一个卷积层
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        # 可分割的卷积层（每个内部已包含ECA）
        spx = torch.split(out, self.width, 1)
        out = spx[0]
        for i in range(self.scale - 1):
            if i == 0:
                sp = spx[i]
            else:
                sp = sp + spx[i]
            sp = self.convs[i](sp)  # 这里面已经包含了ECA的前向传播
            out = torch.cat((out, sp), 1)

        # 最后一个卷积层
        out = self.conv3(out)
        out = self.bn3(out)

        # 整体的ECA注意力
        out = self.eca(out)

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity
        out = self.relu(out)

        return out


class SERes2Net(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="SERes2NetBlock", r=8, scale=4, drop_rate=1):
        super(SERes2Net, self).__init__()

        layers = [eval(block_type)(in_channels, out_channels, scale, r, drop_rate)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = eval(block_type)(out_channels, out_channels, scale, r, drop_rate)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


class SERes2Net_decoder(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="SERes2NetBlock", r=8, scale=4, drop_rate=2):
        super(SERes2Net_decoder, self).__init__()

        layers = [eval(block_type)(in_channels, out_channels, scale, r, 1)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer1 = eval(block_type)(out_channels, out_channels, scale, r, 1)
            layers.append(layer1)
            layer2 = eval(block_type)(out_channels, out_channels * drop_rate, scale, r, drop_rate)
            out_channels *= drop_rate
            layers.append(layer2)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)