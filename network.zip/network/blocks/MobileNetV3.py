import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------- 标准激活函数定义 ---------------------------
class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.inplace = inplace

    def forward(self, x):
        return x * F.relu6(x + 3., inplace=self.inplace) / 6.


class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.inplace = inplace

    def forward(self, x):
        return F.relu6(x + 3., inplace=self.inplace) / 6.


# --------------------------- MobileNetV3 Block（适配表格参数） ---------------------------
class MobileNetV3Block(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, exp_ratio=6, se=True, activation='HS', r=4,
                 drop_rate=1):
        super().__init__()
        self.stride = stride
        self.use_se = se
        self.residual = (in_channels == out_channels) and (stride == 1)

        # 扩张卷积（Pointwise）- 适配表格的expsize
        exp_channels = exp_ratio  # 直接使用表格中的expsize值，而非倍数
        self.expand = nn.Sequential(
            nn.Conv2d(in_channels, exp_channels, 1, 1, 0, bias=False),
            nn.BatchNorm2d(exp_channels),
            self._get_activation(activation)
        )

        # 深度卷积（适配表格的kernel_size和stride）
        self.depthwise = nn.Sequential(
            nn.Conv2d(exp_channels, exp_channels, kernel_size, stride, kernel_size // 2,
                      groups=exp_channels, bias=False),
            nn.BatchNorm2d(exp_channels),
            self._get_activation(activation)
        )

        # SE模块
        if self.use_se:
            self.se = nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(exp_channels, exp_channels // r, 1, 1, 0, bias=False),
                nn.ReLU(inplace=True),
                nn.Conv2d(exp_channels // r, exp_channels, 1, 1, 0, bias=False),
                h_sigmoid()
            )
        else:
            self.se = nn.Identity()

        # 逐点卷积（Pointwise）
        self.project = nn.Sequential(
            nn.Conv2d(exp_channels, out_channels, 1, 1, 0, bias=False),
            nn.BatchNorm2d(out_channels)
        )

    def _get_activation(self, type):
        if type == 'HS':
            return h_swish(inplace=True)
        elif type == 'RE':
            return nn.ReLU(inplace=True)
        else:
            raise ValueError(f"仅支持HS/RE，当前：{type}")

    def forward(self, x):
        identity = x
        out = self.expand(x)  # 升维（1×1）
        out = self.depthwise(out)  # 空间特征（DW）
        out = out * self.se(out)  # 通道注意力
        out = self.project(out)  # 降维（1×1）
        if self.residual:  # 是否跳连
            out += identity
        return out


# --------------------------- MobileNetV3 主网络（集成表格配置） ---------------------------
class MobileNetV3(nn.Module):
    def __init__(self, in_channels=3, out_channels=64, blocks=None, block_type="MobileNetV3Block",
                 r=4, drop_rate=1, encoder_mode=True, target_batch=4, target_h=128, target_w=128):
        super().__init__()
        self.encoder_mode = encoder_mode
        # 核心：固定输出维度参数
        self.target_batch = target_batch  # 4
        self.target_channels = out_channels  # 64
        self.target_h = target_h  # 128
        self.target_w = target_w  # 128
        self.r = r

        # ========== 核心修改：替换为表格的完整配置 ==========
        # 配置说明：[kernel_size, expsize, out_channels, se_flag, activation, stride]
        self.cfg = [
            [3, -1, 8, False, 'HS', 2],  # 层级1: conv2d,3×3 (无exp，stride=2)
            [3, 8, 8, True, 'RE', 1],  # 层级2: bneck,3×3 (expsize=8, SE=√, RE, s=1)
            [3, 24, 12, False, 'RE', 1],  # 层级3: bneck,3×3 (expsize=24, SE=-, RE, s=1)
            [3, 36, 16, False, 'RE', 2],  # 层级4: bneck,3×3 (expsize=36, SE=-, RE, s=2)
            [5, 64, 24, True, 'HS', 1],  # 层级5: bneck,5×5 (expsize=64, SE=√, HS, s=1)
            [5, 96, 32, True, 'HS', 2],  # 层级6: bneck,5×5 (expsize=96, SE=√, HS, s=2)
            [3, 160, 40, False, 'HS', 1],  # 层级7: bneck,3×3 (expsize=160, SE=-, HS, s=1)
            [3, 200, 48, False, 'HS', 2],  # 层级8: bneck,3×3 (expsize=200, SE=-, HS, s=2)
            [5, 288, 64, True, 'HS', 1],  # 层级9: bneck,5×5 (expsize=288, SE=√, HS, s=1)
            [1, -1, 128, False, 'HS', 1],  # 层级10: conv2d (无exp, 1×1)
            [7, -1, -1, False, '-', 1],  # 层级11: pool,7×7 (无输出通道)
            [1, -1, out_channels, False, 'HS', 1]  # 层级12: conv2d,1×1 (输出k类，这里映射到目标通道)
        ]
        # 如果指定blocks，仅取前blocks个配置
        if blocks is not None and blocks > 0:
            self.cfg = self.cfg[:blocks]

        # ========== 网络层构建 ==========
        layers = []
        current_in = in_channels

        for i, (k, exp, c, se, act, s) in enumerate(self.cfg):
            if i == 0:  # 层级1: 初始conv2d,3×3
                layers.append(
                    nn.Sequential(
                        nn.Conv2d(current_in, c, k, s, k // 2, bias=False),
                        nn.BatchNorm2d(c),
                        self._get_activation(act)
                    )
                )
                current_in = c
            elif i == 10:  # 层级11: 全局平均池化
                layers.append(nn.AdaptiveAvgPool2d(1))
            elif i == 11:  # 层级12: 最终1×1卷积
                layers.append(
                    nn.Sequential(
                        nn.Conv2d(current_in, c, k, s, 0, bias=False),
                        nn.BatchNorm2d(c),
                        self._get_activation(act)
                    )
                )
                current_in = c
            elif i == 9:  # 层级10: conv2d (无bottleneck)
                layers.append(
                    nn.Sequential(
                        nn.Conv2d(current_in, c, k, s, 0, bias=False),
                        nn.BatchNorm2d(c),
                        self._get_activation(act)
                    )
                )
                current_in = c
            else:  # 层级2-9: MobileNetV3Block
                layers.append(
                    eval(block_type)(current_in, c, k, s, exp, se, act, self.r)
                )
                current_in = c

        self.backbone = nn.Sequential(*layers)

        # 权重初始化
        self._initialize_weights()

    def _get_activation(self, type):
        if type == 'HS':
            return h_swish(inplace=True)
        elif type == 'RE':
            return nn.ReLU(inplace=True)
        elif type == '-':
            return nn.Identity()
        else:
            raise ValueError(f"仅支持HS/RE/-，当前：{type}")

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # 步骤1：强制输入为4维（适配2维消息/4维图像）
        if x.dim() == 2:
            # 2维输入 → 4维 [B, C, 1, 1]
            x = x.view(self.target_batch, x.shape[1], 1, 1)
        elif x.dim() != 4:
            raise ValueError(f"输入维度必须是2/4维，当前：{x.dim()}")

        # 步骤2：主干网络前向传播
        x = self.backbone(x)

        # 步骤3：强制尺寸为 (128, 128)
        x = F.interpolate(
            x,
            size=(self.target_h, self.target_w),
            mode='bilinear',
            align_corners=False
        )

        # 步骤4：强制批量维度为4
        if x.shape[0] != self.target_batch:
            x = x[:self.target_batch]

        # 最终输出：(4, 64, 128, 128)
        return x


# --------------------------- MobileNetV3_decoder（保留原有逻辑） ---------------------------
class MobileNetV3_decoder(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="MobileNetV3Block",
                 r=4, exp_ratio=6, se=True, activation='HS', drop_rate=2):
        super().__init__()

        # 构建解码器层（对齐SERes2Net_decoder逻辑）
        layers = [
            eval(block_type)(in_channels, out_channels, 3, 1, exp_ratio, se, activation, r, 1)] if blocks != 0 else []
        current_out = out_channels
        for _ in range(blocks - 1):
            # 第一层：保持通道数，步长1
            layer1 = eval(block_type)(current_out, current_out, 3, 1, exp_ratio, se, activation, r, 1)
            layers.append(layer1)
            # 第二层：通道数倍增，步长=drop_rate
            layer2 = eval(block_type)(current_out, current_out * drop_rate, 3, drop_rate, exp_ratio, se, activation, r,
                                      drop_rate)
            current_out *= drop_rate
            layers.append(layer2)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


# --------------------------- 全量测试：验证所有功能 ---------------------------
if __name__ == "__main__":
    # 测试1：图像输入（3通道，匹配表格初始输入）→ 输出(4,64,128,128)
    model_image = MobileNetV3(
        in_channels=3,
        out_channels=64,
        blocks=None,  # 使用完整表格配置
        target_batch=4,
        target_h=128,
        target_w=128
    )
    x_image = torch.randn(4, 3, 128, 128)  # 表格初始输入尺寸128×128×3
    out_image = model_image(x_image)
    assert out_image.shape == (4, 64, 128, 128), f"图像输出维度错误：{out_image.shape}"
    print(f"✅ 图像输入测试通过，输出维度：{out_image.shape}")

    # 测试2：消息输入（128通道）→ 输出(4,64,128,128)
    model_msg = MobileNetV3(
        in_channels=128,
        out_channels=64,
        blocks=None,
        target_batch=4,
        target_h=128,
        target_w=128
    )
    x_msg = torch.randn(4, 128)  # 2维消息输入
    out_msg = model_msg(x_msg)
    assert out_msg.shape == (4, 64, 128, 128), f"消息输出维度错误：{out_msg.shape}"
    print(f"✅ 消息输入测试通过，输出维度：{out_msg.shape}")

    # 测试3：MobileNetV3_decoder 导入&运行
    decoder = MobileNetV3_decoder(in_channels=64, out_channels=64, blocks=2, r=4)
    x_dec = torch.randn(4, 64, 128, 128)
    out_dec = decoder(x_dec)
    print(f"✅ Decoder测试通过，输出维度：{out_dec.shape}")

    # 测试4：单独Block运行（匹配表格层级2）
    block = MobileNetV3Block(in_channels=8, out_channels=8, kernel_size=3, stride=1, exp_ratio=8, se=True,
                             activation='RE')
    x_block = torch.randn(4, 8, 64, 64)
    out_block = block(x_block)
    assert out_block.shape == (4, 8, 64, 64), f"Block输出维度错误：{out_block.shape}"
    print(f"✅ Block测试通过，输出维度：{out_block.shape}")