import os
import qrcode

# ===================== 你的路径 =====================
INPUT_FOLDER = r'D:\MBRS-main\X2\test1'
OUTPUT_FOLDER = r'D:\MBRS-main\X2\test2'

# ===================== 【和目标二维码像素级1:1匹配的参数】 =====================
# 完全复刻目标二维码的密度、大小、细腻度
QR_VERSION = 7
QR_BOX_SIZE = 4
ERROR_CORRECTION = qrcode.constants.ERROR_CORRECT_L
QR_BORDER = 4
# ======================================================================

SUPPORTED_FORMATS = ('.jpg', '.jpeg', '.png', '.bmp', '.gif')


def generate_text_qr(text, save_path):
    qr = qrcode.QRCode(
        version=QR_VERSION,
        error_correction=ERROR_CORRECTION,
        box_size=QR_BOX_SIZE,
        border=QR_BORDER,
    )
    qr.add_data(text)
    qr.make(fit=False)
    # 纯黑白二维码，和示例样式完全一致
    qr_img = qr.make_image(fill_color="black", back_color="white")
    qr_img.save(save_path)


def main():
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    img_list = [f for f in os.listdir(INPUT_FOLDER) if f.lower().endswith(SUPPORTED_FORMATS)]

    if not img_list:
        print("❌ 未找到图片")
        return

    print(f"✅ 找到 {len(img_list)} 张图片，开始生成二维码...\n")
    for filename in img_list:
        qr_filename = f"{os.path.splitext(filename)[0]}_text_qr.png"
        qr_save_path = os.path.join(OUTPUT_FOLDER, qr_filename)

        print(f"正在处理: {filename}")
        # 二维码内容设置为图片文件名，微信扫码直接显示文本
        generate_text_qr(filename, qr_save_path)
        print(f"✅ 二维码生成成功: {qr_filename}\n")

    print("🎉 全部生成完成！")
    print("微信扫码会直接显示图片文件名，无任何限制！")
    input("按回车键退出程序...")


if __name__ == "__main__":
    main()