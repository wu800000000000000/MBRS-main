import torch
import torch.nn as nn
import torch.nn.functional as F

# --------------------------- 标准激活函数定义 ---------------------------
class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.inplace = inplace

    def forward(self, x):
        return x * F.relu6(x + 3., inplace=self.inplace) / 6.

class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.inplace = inplace

    def forward(self, x):
        return F.relu6(x + 3., inplace=self.inplace) / 6.

# --------------------------- MobileNetV3 Block 核心模块 ---------------------------
class MobileNetBlock(nn.Module):
    def __init__(self, in_channels, out_channels, r=8, exp_ratio=6, se=True, activation='HS', drop_rate=1):
        super(MobileNetBlock, self).__init__()
        self.drop_rate = drop_rate  # 步长（对应原drop_rate）
        self.width = out_channels  # 输出通道宽度
        self.downsample = None

        # 残差连接：通道/尺寸不匹配时的下采样
        if in_channels != out_channels or drop_rate != 1:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=drop_rate, padding=0, bias=False),
                nn.BatchNorm2d(out_channels)
            )

        # 1. 扩张卷积（Pointwise Conv）
        exp_channels = int(in_channels * exp_ratio)
        self.expand_conv = nn.Sequential(
            nn.Conv2d(in_channels, exp_channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(exp_channels),
            self._get_activation(activation)
        )

        # 2. 深度卷积（Depthwise Conv）
        self.depthwise_conv = nn.Sequential(
            nn.Conv2d(exp_channels, exp_channels, kernel_size=3, stride=drop_rate, padding=1,
                      groups=exp_channels, bias=False),
            nn.BatchNorm2d(exp_channels),
            self._get_activation(activation)
        )

        # 3. SE注意力模块（对应SERes2Net的r参数）
        self.se = nn.Identity()
        if se:
            self.se = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(exp_channels, exp_channels // r, kernel_size=1, bias=False),
                nn.ReLU(inplace=True),
                nn.Conv2d(exp_channels // r, exp_channels, kernel_size=1, bias=False),
                nn.Sigmoid()
            )

        # 4. 逐点卷积（Pointwise Conv）
        self.project_conv = nn.Sequential(
            nn.Conv2d(exp_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(out_channels)
        )

        # 激活函数
        self.relu = nn.ReLU(inplace=True)

    def _get_activation(self, type):
        """获取激活函数（HS=h-swish, RE=ReLU）"""
        if type == 'HS':
            return nn.Hardswish(inplace=True)
        elif type == 'RE':
            return nn.ReLU(inplace=True)
        else:
            raise ValueError(f"不支持的激活函数: {type}")

    def forward(self, x):
        identity = x

        # 扩张卷积
        out = self.expand_conv(x)
        # 深度卷积
        out = self.depthwise_conv(out)
        # SE注意力
        out = out * self.se(out)
        # 逐点卷积
        out = self.project_conv(out)

        # 残差连接适配
        if self.downsample is not None:
            identity = self.downsample(identity)

        # 残差相加 + 激活
        out += identity
        out = self.relu(out)

        return out


# --------------------------- MobileNetV3 主网络（对齐SERes2Net） ---------------------------
class MobileNet(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="MobileNetBlock",
                 r=8, exp_ratio=6, se=True, activation='HS', drop_rate=1):
        super(MobileNet, self).__init__()

        # 构建网络层（对齐SERes2Net的layers构建逻辑）
        layers = [
            eval(block_type)(in_channels, out_channels, r, exp_ratio, se, activation, drop_rate)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = eval(block_type)(out_channels, out_channels, r, exp_ratio, se, activation, drop_rate)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


# --------------------------- MobileNetV3 解码器（对齐SERes2Net_decoder） ---------------------------
class MobileNet_decoder(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="MobileNetBlock",
                 r=8, exp_ratio=6, se=True, activation='HS', drop_rate=2):
        super(MobileNet_decoder, self).__init__()

        # 构建解码器层（对齐SERes2Net_decoder的双层循环逻辑）
        layers = [eval(block_type)(in_channels, out_channels, r, exp_ratio, se, activation, 1)] if blocks != 0 else []
        current_out = out_channels
        for _ in range(blocks - 1):
            # 第一层：保持通道数，步长1
            layer1 = eval(block_type)(current_out, current_out, r, exp_ratio, se, activation, 1)
            layers.append(layer1)
            # 第二层：通道数倍增，步长=drop_rate（上采样/下采样）
            layer2 = eval(block_type)(current_out, current_out * drop_rate, r, exp_ratio, se, activation, drop_rate)
            current_out *= drop_rate
            layers.append(layer2)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


# --------------------------- 测试代码（验证格式兼容性） ---------------------------
if __name__ == "__main__":
    # 1. 测试MobileNetV3主网络（对齐SERes2Net调用方式）
    model = MobileNet(in_channels=64, out_channels=64, blocks=4, r=8, exp_ratio=6, drop_rate=1)
    x = torch.randn(4, 64, 32, 32)
    out = model(x)
    print(f"MobileNet输出形状: {out.shape}")  # [4,64,32,32]

    # 2. 测试MobileNetV3解码器（对齐SERes2Net_decoder调用方式）
    decoder = MobileNet_decoder(in_channels=64, out_channels=64, blocks=2, r=8, drop_rate=2)
    x = torch.randn(4, 64, 32, 32)
    out = decoder(x)
    print(f"MobileNet解码器输出形状: {out.shape}")  # [4,256,16,16]

    # 3. 测试单独Block
    block = MobileNetBlock(in_channels=64, out_channels=64, r=8, drop_rate=1)
    x = torch.randn(4, 64, 32, 32)
    out = block(x)
    print(f"MobileNetBlock输出形状: {out.shape}")  # [4,64,32,32]
