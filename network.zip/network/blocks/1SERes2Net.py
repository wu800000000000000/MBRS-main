import torch.nn as nn
import torch.nn.functional as F
import torch




class BottleneckBlock(nn.Module):
    def __init__(self, in_channels, out_channels, r, scale, drop_rate):
        super(BottleneckBlock, self).__init__()
        width = int(out_channels / scale)

        self.downsample = None
        if (in_channels != out_channels):
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1, padding=0,
                          stride=drop_rate, bias=False),
                nn.BatchNorm2d(out_channels)
            )

        self.conv1 = nn.Conv2d(in_channels, width, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(width)
        self.conv2 = nn.Conv2d(width, width, kernel_size=3, padding=1, stride=drop_rate, bias=False)
        self.bn2 = nn.BatchNorm2d(width)
        self.conv3 = nn.Conv2d(width, out_channels, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)

        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(out_channels, out_channels // r, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels // r, out_channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = F.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        scale = self.se(out)
        out = out * scale

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity
        out = F.relu(out)
        return out


class SERes2NetBlock(nn.Module):
    def __init__(self, in_channels, out_channels, scale, r, drop_rate):
        super(SERes2NetBlock, self).__init__()
        self.scale = scale
        self.width = out_channels // scale
        self.downsample = None

        if in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=drop_rate, bias=False),
                nn.BatchNorm2d(out_channels)
            )

        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

        # 可分割的卷积层
        self.convs = nn.ModuleList()
        for i in range(scale - 1):
            self.convs.append(nn.Sequential(
                nn.Conv2d(self.width, self.width, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(self.width),
                nn.ReLU(inplace=True)
            ))

         # 通道混洗


        # 最后一个卷积层
        self.conv3 = nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=drop_rate, bias=False)
        self.bn3 = nn.BatchNorm2d(out_channels)

        # Squeeze-and-Excitation模块
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(out_channels, out_channels // r, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels // r, out_channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        identity = x

        # 第一个卷积层
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        # 可分割的卷积层
        spx = torch.split(out, self.width, 1)  # 将张量 out 按照维度 1（通道维度）分割成多个子张量
        out = spx[0]   # 将分割后的第一个子张量赋值给变量 out，作为后续拼接的初始值
        for i in range(self.scale - 1):  # 循环 self.scale - 1 次，self.scale 是一个预定义的参数，表示分割的块数
            if i == 0:
                sp = spx[i]   # 如果当前是第一次循环（i == 0），将第一个子张量 spx[i] 赋值给变量 sp
            else:
                sp = sp + spx[i]   # 如果不是第一次循环，则将当前子张量 spx[i] 加到变量 sp 上。这里假设子张量的形状是相同的，可以直接进行逐元素相加。
            sp = self.convs[i](sp)  # 对变量 sp 应用第 i 个卷积操作 self.convs[i]。self.convs 是一个包含多个卷积层的列表。
            out = torch.cat((out, sp), 1)  # 将经过卷积操作后的结果 sp 拼接到变量 out 上，拼接的维度是通道维度（维度 1）。这样逐步构建最终的输出张量

        # 最后一个卷积层
        out = self.conv3(out)
        out = self.bn3(out)

        # Squeeze-and-Excitation模块
        scale = self.se(out)
        out = out * scale

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity # 输入x与identity相加，用于实现残差连接
        out = self.relu(out) # 对相加后的结果应用ReLU激活函数

        return out


class SERes2Net(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="SERes2NetBlock", r=8, scale=4, drop_rate=1):
        super(SERes2Net, self).__init__()

        layers = [eval(block_type)(in_channels, out_channels, r, scale, drop_rate)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = eval(block_type)(out_channels, out_channels, r, scale, drop_rate)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


class SERes2Net_decoder(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="SERes2NetBlock", r=8, scale=4, drop_rate=2):
        super(SERes2Net_decoder, self).__init__()

        layers = [eval(block_type)(in_channels, out_channels, r, scale, 1)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer1 = eval(block_type)(out_channels, out_channels, r, scale, 1)
            layers.append(layer1)
            layer2 = eval(block_type)(out_channels, out_channels * drop_rate, r, scale, drop_rate)
            out_channels *= drop_rate
            layers.append(layer2)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)
