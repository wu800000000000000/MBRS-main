import torch
import torch.nn as nn
import torch.nn.functional as F

# --------------------------- 标准激活函数定义 ---------------------------
class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.inplace = inplace

    def forward(self, x):
        return x * F.relu6(x + 3., inplace=self.inplace) / 6.

class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.inplace = inplace

    def forward(self, x):
        return F.relu6(x + 3., inplace=self.inplace) / 6.

# --------------------------- MobileNetV3 Block（关闭下采样） ---------------------------
class MobileNetV3Block(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, exp_ratio=6, se=True, activation='HS', r=4, drop_rate=1):
        super().__init__()
        self.stride = stride
        self.use_se = se
        self.residual = (in_channels == out_channels) and (stride == 1)

        # 扩张卷积（Pointwise）
        exp_channels = int(in_channels * exp_ratio)
        self.expand = nn.Sequential(
            nn.Conv2d(in_channels, exp_channels, 1, 1, 0, bias=False),
            nn.BatchNorm2d(exp_channels),
            self._get_activation(activation)
        )

        # 深度卷积（关键：stride固定为1，避免下采样缩小尺寸）
        self.depthwise = nn.Sequential(
            nn.Conv2d(exp_channels, exp_channels, kernel_size, 1, kernel_size//2,
                      groups=exp_channels, bias=False),  # stride=1
            nn.BatchNorm2d(exp_channels),
            self._get_activation(activation)
        )

        # SE模块
        if self.use_se:
            self.se = nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(exp_channels, exp_channels // r, 1, 1, 0, bias=False),
                nn.ReLU(inplace=True),
                nn.Conv2d(exp_channels // r, exp_channels, 1, 1, 0, bias=False),
                h_sigmoid()
            )
        else:
            self.se = nn.Identity()

        # 逐点卷积（Pointwise）
        self.project = nn.Sequential(
            nn.Conv2d(exp_channels, out_channels, 1, 1, 0, bias=False),
            nn.BatchNorm2d(out_channels)
        )

    def _get_activation(self, type):    #类内部私有方法，调用时传进来一个字符串 type
        if type == 'HS':                #如果字符串是 'HS'，就返回 h-swish 激活函数
            return h_swish(inplace=True)
        elif type == 'RE':              #如果字符串是 'RE'，就返回 ReLU
            return nn.ReLU(inplace=True) #最常见的激活函数，同样原地计算
        else:                            #传进来的字符串既不是 'HS' 也不是 'RE'
            raise ValueError(f"仅支持HS/RE，当前：{type}")   #直接抛异常，告诉你“我只认 HS 和 RE，别瞎传”。

    def forward(self, x):
        identity = x
        out = self.expand(x)    #升维（1×1）
        out = self.depthwise(out)   #空间特征（3×3 DW）
        out = out * self.se(out)   #通道注意力
        out = self.project(out)   #降维（1×1）
        if self.residual:    #是否跳连
            out += identity
        return out

# --------------------------- MobileNetV3 主网络（强制输出(4,64,128,128)） ---------------------------
class MobileNetV3(nn.Module):
    def __init__(self, in_channels=3, out_channels=64, blocks=4, block_type="MobileNetV3Block",
                 r=4, drop_rate=1, encoder_mode=True, target_batch=4, target_h=128, target_w=128):
        super().__init__()
        self.encoder_mode = encoder_mode
        # 核心：固定输出维度参数
        self.target_batch = target_batch  # 4
        self.target_channels = out_channels  # 64
        self.target_h = target_h  # 128
        self.target_w = target_w  # 128
        self.r = r

        # 仅保留官方MobileNetV3-Small配置（简化版，避免尺寸变化）
        self.cfg = [
            [3, 1, 16, False, 'RE'],   #深度卷积的 kernel size（3×3 或 5×5）
            [3, 4.5, 24, False, 'RE'],  #expansion ratio（升维倍数，1 表示不升维）
            [3, 3.67, 24, False, 'RE'],  #该块输出的通道数
            [5, 4, 40, True, 'HS'],   #是否在该块里插入SE注意力，该块使用的激活函数，RE=ReLU，HS=h-swish
        ][:blocks]  # 仅取前blocks个，默认4个

        # ========== 核心修复：输入通道适配层 ==========
        # 解决"输入通道数不匹配"问题，将任意输入通道转为16
        self.input_adapter = nn.Sequential(
            nn.Conv2d(in_channels, 16, 1, 1, 0, bias=False),
            nn.BatchNorm2d(16),
            h_swish(inplace=True)
        )

        # 初始卷积层（输入通道固定为16，stride=1）
        self.initial_conv = nn.Sequential(
            nn.Conv2d(16, 16, 3, 1, 1, bias=False),
            nn.BatchNorm2d(16),
            h_swish(inplace=True)
        )

        # 构建主干层
        layers = []
        current_in = 16
        for k, exp, c, se, act in self.cfg:
            layers.append(eval(block_type)(current_in, c, k, 1, exp, se, act, self.r))
            current_in = c
        self.backbone = nn.Sequential(*layers)

        # 输出适配层（强制通道数=64）
        self.output_adapter = nn.Sequential(
            nn.Conv2d(current_in, self.target_channels, 1, 1, 0, bias=False),
            nn.BatchNorm2d(self.target_channels),
            h_swish(inplace=True)
        )

        # 权重初始化
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # 步骤1：强制输入为4维（适配2维消息/4维图像）
        if x.dim() == 2:
            # 2维输入 → 4维 [B, C, 1, 1]
            x = x.view(self.target_batch, x.shape[1], 1, 1)
        elif x.dim() != 4:
            raise ValueError(f"输入维度必须是2/4维，当前：{x.dim()}")

        # 步骤2：适配输入通道数（核心修复）
        x = self.input_adapter(x)  # 任意通道 → 16通道

        # 步骤3：正常前向传播
        x = self.initial_conv(x)
        x = self.backbone(x)
        x = self.output_adapter(x)  # 通道数 → 64

        # 步骤4：强制尺寸为 (128, 128)
        x = F.interpolate(
            x,
            size=(self.target_h, self.target_w),
            mode='bilinear',
            align_corners=False
        )

        # 步骤5：强制批量维度为4
        if x.shape[0] != self.target_batch:
            x = x[:self.target_batch]

        # 最终输出：(4, 64, 128, 128)
        return x

# --------------------------- MobileNetV3_decoder（必须保留，解决导入失败） ---------------------------
class MobileNetV3_decoder(nn.Module):
    def __init__(self, in_channels, out_channels, blocks, block_type="MobileNetV3Block",
                 r=4, exp_ratio=6, se=True, activation='HS', drop_rate=2):
        super().__init__()

        # 构建解码器层（对齐SERes2Net_decoder逻辑）
        layers = [eval(block_type)(in_channels, out_channels, 3, 1, exp_ratio, se, activation, r, 1)] if blocks != 0 else []
        current_out = out_channels
        for _ in range(blocks - 1):
            # 第一层：保持通道数，步长1
            layer1 = eval(block_type)(current_out, current_out, 3, 1, exp_ratio, se, activation, r, 1)
            layers.append(layer1)
            # 第二层：通道数倍增，步长=drop_rate
            layer2 = eval(block_type)(current_out, current_out * drop_rate, 3, drop_rate, exp_ratio, se, activation, r, drop_rate)
            current_out *= drop_rate
            layers.append(layer2)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)

# --------------------------- 全量测试：验证所有功能 ---------------------------
if __name__ == "__main__":
    # 测试1：图像输入（64通道）→ 输出(4,64,128,128)
    model_image = MobileNetV3(
        in_channels=64,
        out_channels=64,
        blocks=4,
        target_batch=4,
        target_h=128,
        target_w=128
    )
    x_image = torch.randn(4, 64, 256, 256)
    out_image = model_image(x_image)
    assert out_image.shape == (4, 64, 128, 128), f"图像输出维度错误：{out_image.shape}"
    print(f"✅ 图像输入测试通过，输出维度：{out_image.shape}")

    # 测试2：消息输入（128通道）→ 输出(4,64,128,128)
    model_msg = MobileNetV3(
        in_channels=128,
        out_channels=64,
        blocks=4,
        target_batch=4,
        target_h=128,
        target_w=128
    )
    x_msg = torch.randn(4, 128)  # 2维消息输入
    out_msg = model_msg(x_msg)
    assert out_msg.shape == (4, 64, 128, 128), f"消息输出维度错误：{out_msg.shape}"
    print(f"✅ 消息输入测试通过，输出维度：{out_msg.shape}")

    # 测试3：MobileNetV3_decoder 导入&运行
    decoder = MobileNetV3_decoder(in_channels=64, out_channels=64, blocks=2, r=4)
    x_dec = torch.randn(4, 64, 128, 128)
    out_dec = decoder(x_dec)
    print(f"✅ Decoder测试通过，输出维度：{out_dec.shape}")

    # 测试4：单独Block运行
    block = MobileNetV3Block(in_channels=64, out_channels=64, kernel_size=3)
    x_block = torch.randn(4, 64, 128, 128)
    out_block = block(x_block)
    assert out_block.shape == (4, 64, 128, 128), f"Block输出维度错误：{out_block.shape}"
    print(f"✅ Block测试通过，输出维度：{out_block.shape}")