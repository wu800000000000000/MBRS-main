from network import *
from network.blocks.SERes2Net import SERes2Net

class Discriminator(nn.Module):
    '''
	Adversary to discriminate the cover image and the encoded image
	'''

    def __init__(self, blocks=4, channels=64):
        super(Discriminator, self).__init__()

        self.layers = nn.Sequential(
            SERes2Net(3, channels, blocks),
            nn.AdaptiveAvgPool2d(output_size=(1, 1))
        )

        self.linear = nn.Linear(channels, 1)

    def forward(self, image):
        x = self.layers(image)
        x.squeeze_(3).squeeze_(2)
        x = self.linear(x)
        return x

    # 新增：统计参数数量（与编码器/解码器格式完全一致）
    def count_parameters(self, trainable_only=False):
        """
		统计模型参数数量
		Args:
			trainable_only: 是否只统计可训练参数（默认False，统计所有参数）
		Returns:
			total_params: 参数总数
		"""
        if trainable_only:
            total_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        else:
            total_params = sum(p.numel() for p in self.parameters())
        return total_params

    # 新增：打印参数详细信息（与编码器/解码器格式完全一致）
    def print_parameter_info(self):
        """打印模型参数统计信息"""
        total_params = self.count_parameters()
        trainable_params = self.count_parameters(trainable_only=True)
        non_trainable_params = total_params - trainable_params

        # 格式化输出参数数量（带千分位分隔符）
        print(f"=== Discriminator 参数统计 ===")
        print(f"总参数数量: {total_params:,}")
        print(f"可训练参数: {trainable_params:,}")
        print(f"不可训练参数: {non_trainable_params:,}")


# 示例调用方式（可根据需要选择是否保留）
if __name__ == "__main__":
    # 初始化判别器并查看参数
    discriminator = Discriminator(blocks=4, channels=64)
    discriminator.print_parameter_info()

    # 单独获取参数数量
    print(f"\nDiscriminator 可训练参数数量: {discriminator.count_parameters(trainable_only=True):,}")
    print(f"Discriminator 总参数数量: {discriminator.count_parameters():,}")