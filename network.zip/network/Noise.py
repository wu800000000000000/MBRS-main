from network import *
from network.noise_layers import *


class Noise(nn.Module):

	def __init__(self, layers): #初始化函数，接收一个包含层定义的列表
		super(Noise, self).__init__()  #调用父类的初始化函数
		for i in range(len(layers)):  #遍历层定义列表
			layers[i] = eval(layers[i])  #将层定义字符串转换为实际的层对象
		self.noise = nn.Sequential(*layers)  #创建一个顺序容器，包含所有层

	def forward(self, image_and_cover): #前向传播函数，接收一个包含图像和掩码的元组
		noised_image = self.noise(image_and_cover)  #将输入通过噪声模型
		return noised_image  #返回添加了噪声的图像
