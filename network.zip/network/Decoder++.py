from network import *
import torch.nn as nn
import numpy as np
import torch
from network.blocks.MobileNetV3 import MobileNetV3_decoder
from network.blocks.MobileNet import MobileNet_decoder


class Decoder(nn.Module):
    '''
    单块版水印解码器：仅用1个特征提取块，输出维度固定为[1,64]
    输入：带水印图像 (batch, 3, H, W)
    输出：提取的水印信息 (batch, message_length)
    '''

    def __init__(self, H=128, W=128, message_length=64, channels=64, use_diffusion=False, diffusion_length=256):
        super().__init__()
        self.H = H
        self.W = W
        self.msg_len = message_length
        self.channels = channels
        self.use_diffusion = use_diffusion
        self.diffusion_length = diffusion_length

        # 目标水印尺寸（展平后为message_length）
        self.target_size = int(np.sqrt(message_length))  # 8（8×8=64）
        self.diffusion_size = int(np.sqrt(diffusion_length)) if use_diffusion else self.target_size

        # ========== 核心配置：仅用1个块 ==========
        self.blocks = 1  # 固定1个块

        # 1. 图像预处理层（3→64通道）
        self.image_pre = ConvBNRelu(3, self.channels)

        # 2. 核心下采样块：仅1个MobileNet解码器
        self.downsample_block = MobileNet_decoder(
            self.channels,
            self.channels,
            blocks=self.blocks
        )

        # 3. 特征保留层：仅1个MobileNetV3解码器块
        self.keep_layers = MobileNetV3_decoder(self.channels, self.channels, blocks=self.blocks)

        # 4. 最终特征→单通道水印图
        self.final_layer = ConvBNRelu(self.channels, 1)

        # 5. 尺寸适配层：强制压缩到目标尺寸（关键修复）
        self.size_adapter = nn.AdaptiveAvgPool2d((self.target_size, self.target_size))

        # 6. 扩散模式：水印维度还原
        if self.use_diffusion:
            self.diffusion_adapter = nn.AdaptiveAvgPool2d((self.diffusion_size, self.diffusion_size))
            self.message_layer = nn.Linear(self.diffusion_length, self.msg_len)

    def forward(self, noised_image):
        """
        前向传播：输出维度固定为[1,64]
        """
        # 1. 图像预处理（3→64通道）
        x = self.image_pre(noised_image)
        print(f"预处理后通道数: {x.shape[1]}")

        # 2. 下采样（仅1个块）
        x = self.downsample_block(x)
        print(f"下采样后通道数: {x.shape[1]}")

        # 3. 特征保留（仅1个块）
        x = self.keep_layers(x)
        print(f"特征保留后通道数: {x.shape[1]}")

        # 4. 转为单通道水印图
        x = self.final_layer(x)
        print(f"单通道水印图形状: {x.shape}")

        # ========== 关键修复：强制适配到目标尺寸 ==========
        if self.use_diffusion:
            # 扩散模式：先适配到扩散尺寸，再展平
            x = self.diffusion_adapter(x)
            print(f"扩散模式尺寸适配后: {x.shape}")
            x = x.view(x.shape[0], -1)
            print(f"扩散模式展平后维度: {x.shape}")
            # 还原到目标消息长度
            x = self.message_layer(x)
        else:
            # 基础模式：直接适配到8×8，展平后64
            x = self.size_adapter(x)
            print(f"基础模式尺寸适配后: {x.shape}")
            x = x.view(x.shape[0], -1)
            print(f"基础模式展平后维度: {x.shape}")

        return x


# 测试：验证输出维度均为[1,64]
if __name__ == "__main__":
    # 基础参数
    H = 128
    W = 128
    message_length = 64
    channels = 64

    # ========== 测试基础模式 ==========
    print("=== 基础模式解码 ===")
    decoder_base = Decoder(
        H=H, W=W,
        message_length=message_length,
        channels=channels,
        use_diffusion=False
    )
    watermarked_image = torch.randn(1, 3, 128, 128)
    msg_base = decoder_base(watermarked_image)
    print(f"基础模式最终提取水印维度: {msg_base.shape}")  # 期望 [1,64]

    # ========== 测试扩散模式 ==========
    print("\n=== 扩散模式解码 ===")
    decoder_diff = Decoder(
        H=H, W=W,
        message_length=message_length,
        channels=channels,
        use_diffusion=True,
        diffusion_length=256
    )
    msg_diff = decoder_diff(watermarked_image)
    print(f"扩散模式最终提取水印维度: {msg_diff.shape}")  # 期望 [1,64]