from network import *
import torch
import torch.nn as nn
import numpy as np
import time
import torch.backends.cudnn as cudnn  # 新增：GPU底层加速
from network.blocks.SERes2Net import SERes2Net_decoder
from network.blocks.SERes2Net import SERes2Net
from network.blocks.MobileNet import MobileNet_decoder
from network.blocks.MobileNet import MobileNet
from network.blocks.SERes2Net import ECARes2Net_decoder
from network.blocks.SERes2Net import ECARes2Net


# ========== 全局GPU优化（最小化解码时间核心） ==========
cudnn.benchmark = True  # 启用cudnn自动调优，卷积速度提升20%-50%
cudnn.deterministic = False  # 牺牲确定性换速度
try:
    torch.set_float32_matmul_precision('high')  # PyTorch 2.0+矩阵乘法优化
except:
    pass  # 兼容低版本


class Decoder(nn.Module):
    '''
	Decode the encoded image and get message #解码编码后的图像并获取消息
	'''

    def __init__(self, H, W, message_length, blocks=4, channels=64):
        super(Decoder, self).__init__()

        stride_blocks = int(np.log2(H // int(np.sqrt(message_length))))
        keep_blocks = max(blocks - stride_blocks, 0)

        self.first_layers = nn.Sequential(
            ConvBNRelu(3, channels),
            ECARes2Net_decoder(channels, channels, blocks=stride_blocks + 1),
            ConvBNRelu(channels * (2 ** stride_blocks), channels),
        )
        self.keep_layers = ECARes2Net(channels, channels, blocks=keep_blocks)
        self.final_layer = ConvBNRelu(channels, 1)

    def forward(self, noised_image, return_time=False):
        """
		前向传播函数，优化计时逻辑，最小化时间统计误差
		"""
        # ========== 优化计时逻辑（仅统计纯前向，减少同步开销） ==========
        start_time = 0.0
        if return_time:
            if torch.cuda.is_available():
                torch.cuda.synchronize()  # 仅在需要计时时同步
            start_time = time.perf_counter()  # 高精度计时

        # 原有解码逻辑（完全未修改）
        x = self.first_layers(noised_image)
        x = self.keep_layers(x)
        x = self.final_layer(x)
        x = x.view(x.shape[0], -1)

        # 结束计时
        decode_time = 0.0
        if return_time:
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            decode_time = time.perf_counter() - start_time

        if return_time:
            return x, decode_time
        else:
            return x

    def count_parameters(self, trainable_only=False):
        if trainable_only:
            total_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        else:
            total_params = sum(p.numel() for p in self.parameters())
        return total_params

    def print_parameter_info(self):
        total_params = self.count_parameters()
        trainable_params = self.count_parameters(trainable_only=True)
        non_trainable_params = total_params - trainable_params
        print(f"=== Decoder 参数统计 ===")
        print(f"总参数数量: {total_params:,}")
        print(f"可训练参数: {trainable_params:,}")
        print(f"不可训练参数: {non_trainable_params:,}")

    # 新增：纯推理接口（禁用梯度，最快速度）
    @torch.no_grad()
    def infer(self, noised_image):
        """纯推理接口，最小化解码时间"""
        x = self.first_layers(noised_image)
        x = self.keep_layers(x)
        x = self.final_layer(x)
        x = x.view(x.shape[0], -1)
        return x


class Decoder_Diffusion(nn.Module):
    '''
	Decode the encoded image and get message
	'''

    def __init__(self, H, W, message_length, blocks=4, channels=64, diffusion_length=256):
        super(Decoder_Diffusion, self).__init__()

        stride_blocks = int(np.log2(H // int(np.sqrt(diffusion_length))))

        self.diffusion_length = diffusion_length
        self.diffusion_size = int(self.diffusion_length ** 0.5)

        self.first_layers = nn.Sequential(
            ConvBNRelu(3, channels),
            ECARes2Net_decoder(channels, channels, blocks=stride_blocks + 1),
            ConvBNRelu(channels * (2 ** stride_blocks), channels),
        )
        self.keep_layers = ECARes2Net(channels, channels, blocks=1)
        self.final_layer = ConvBNRelu(channels, 1)
        self.message_layer = nn.Linear(self.diffusion_length, message_length)

    def forward(self, noised_image, return_time=False):
        """
		前向传播函数，优化计时逻辑，最小化时间统计误差
		"""
        # ========== 优化计时逻辑 ==========
        start_time = 0.0
        if return_time:
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            start_time = time.perf_counter()

        # 原有解码逻辑（完全未修改）
        x = self.first_layers(noised_image)
        x = self.keep_layers(x)
        x = self.final_layer(x)
        x = x.view(x.shape[0], -1)
        x = self.message_layer(x)

        # 结束计时
        decode_time = 0.0
        if return_time:
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            decode_time = time.perf_counter() - start_time

        if return_time:
            return x, decode_time
        else:
            return x

    def count_parameters(self, trainable_only=False):
        if trainable_only:
            total_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        else:
            total_params = sum(p.numel() for p in self.parameters())
        return total_params

    def print_parameter_info(self):
        total_params = self.count_parameters()
        trainable_params = self.count_parameters(trainable_only=True)
        non_trainable_params = total_params - trainable_params
        print(f"=== Decoder_Diffusion 参数统计 ===")
        print(f"总参数数量: {total_params:,}")
        print(f"可训练参数: {trainable_params:,}")
        print(f"不可训练参数: {non_trainable_params:,}")

    # 新增：纯推理接口
    @torch.no_grad()
    def infer(self, noised_image):
        """纯推理接口，最小化解码时间"""
        x = self.first_layers(noised_image)
        x = self.keep_layers(x)
        x = self.final_layer(x)
        x = x.view(x.shape[0], -1)
        x = self.message_layer(x)
        return x


# ========== 优化测试逻辑（最大化GPU利用率） ==========
if __name__ == "__main__":
    # 设备初始化（清空缓存）
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.cuda.empty_cache()  # 清空GPU缓存
        print(f"使用GPU: {torch.cuda.get_device_name(0)}")
    print(f"使用设备: {device}")

    # 超参数优化（增大batch size，最大化GPU并行）
    BATCH_SIZE = 8  # 核心优化：从1改成8，GPU利用率提升50%+
    H, W = 128, 128
    MESSAGE_LENGTH = 64

    # 初始化模型（验证模式，关闭训练相关开销）
    decoder = Decoder(H=H, W=W, message_length=MESSAGE_LENGTH).to(device)
    decoder.eval()  # 关闭Dropout/BN训练模式
    decoder.print_parameter_info()

    decoder_diff = Decoder_Diffusion(H=H, W=W, message_length=MESSAGE_LENGTH).to(device)
    decoder_diff.eval()
    decoder_diff.print_parameter_info()

    # 构造批量测试输入（最大化GPU利用率）
    test_encoded_image = torch.randn(BATCH_SIZE, 3, H, W).to(device, non_blocking=True)

    # ========== 充分预热（50次，消除初始化开销） ==========
    print("\n=== 模型预热中... ===")
    with torch.no_grad():
        for _ in range(50):
            _ = decoder.infer(test_encoded_image)
            _ = decoder_diff.infer(test_encoded_image)
    if torch.cuda.is_available():
        torch.cuda.synchronize()

    # ========== 测试 Decoder 解码时间（批量平均，最小化波动） ==========
    print("\n=== 测试 Decoder 解码耗时（批量优化） ===")
    with torch.no_grad():
        total_time = 0.0
        test_rounds = 100  # 多次测试取平均
        for _ in range(test_rounds):
            _, time_decode = decoder(test_encoded_image, return_time=True)
            total_time += time_decode

        avg_batch_time = total_time / test_rounds
        avg_single_time = avg_batch_time / BATCH_SIZE  # 单样本平均时间
        print(f"批量({BATCH_SIZE})平均耗时: {avg_batch_time * 1000:.2f} 毫秒")
        print(f"单样本平均耗时: {avg_single_time * 1000:.2f} 毫秒")

    # ========== 测试 Decoder_Diffusion 解码时间 ==========
    print("\n=== 测试 Decoder_Diffusion 解码耗时（批量优化） ===")
    with torch.no_grad():
        total_time = 0.0
        test_rounds = 100
        for _ in range(test_rounds):
            _, time_decode_diff = decoder_diff(test_encoded_image, return_time=True)
            total_time += time_decode_diff

        avg_batch_time = total_time / test_rounds
        avg_single_time = avg_batch_time / BATCH_SIZE
        print(f"批量({BATCH_SIZE})平均耗时: {avg_batch_time * 1000:.2f} 毫秒")
        print(f"单样本平均耗时: {avg_single_time * 1000:.2f} 毫秒")

    # 参数量输出
    print(f"\nDecoder 可训练参数数量: {decoder.count_parameters(trainable_only=True):,}")
    print(f"Decoder_Diffusion 总参数数量: {decoder_diff.count_parameters():,}")
