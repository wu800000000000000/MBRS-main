from network import *
import torch
import torch.nn as nn
import numpy as np
from network.blocks.MobileNetV3 import MobileNetV3  # 仅保留MobileNetV3依赖


class Encoder_MP(nn.Module):
    '''
    单块版水印编码器：修复MobileNetV3输出通道强制修改问题
    输入：图像张量 (batch, 3, H, W) + 水印张量 (batch, msg_len)
    输出：嵌入水印后的图像张量 (batch, 3, H, W)
    '''

    def __init__(self, H=128, W=128, message_length=64, channels=64):
        super().__init__()
        self.H = H
        self.W = W
        self.msg_len = message_length
        self.channels = channels  # 核心通道数

        # 计算消息上采样块数
        msg_sqrt = int(np.sqrt(message_length))
        message_convT_blocks = int(np.log2(H // msg_sqrt))

        # ========== 核心配置 ==========
        self.blocks = 1  # 固定1个MobileNetV3块

        # 1. 图像预处理层（3→64通道）
        self.image_pre_layer = ConvBNRelu(3, self.channels)

        # 2. 水印预处理+上采样层（1→64通道→上采样）
        self.message_pre_layer = nn.Sequential(
            ConvBNRelu(1, self.channels),
            ExpandNet(self.channels, self.channels, blocks=message_convT_blocks)
        )

        # 3. 核心：1个MobileNetV3块 + 通道适配层（解决输出通道被改为8的问题）
        self.mobilenetv3_block = MobileNetV3(
            in_channels=self.channels,
            out_channels=self.channels,
            blocks=self.blocks
        )
        # 通道适配层：强制将MobileNetV3输出（8通道）转回64通道
        self.channel_adapter = ConvBNRelu(8, self.channels)

        # 4. 特征融合层（2×64=128→64通道）
        self.after_concat_layer = ConvBNRelu(2 * self.channels, self.channels)

        # 5. 最终输出层（64→3通道）
        self.final_layer = nn.Conv2d(self.channels, 3, kernel_size=1, bias=False)

    def forward(self, image, message):
        """
        前向传播：修复MobileNetV3输出通道不匹配问题
        """
        # ========== 1. 水印处理 ==========
        msg_sqrt = int(np.sqrt(message.shape[1]))
        message_image = message.view(-1, 1, msg_sqrt, msg_sqrt)
        message_feat = self.message_pre_layer(message_image)
        print(f"水印特征通道数: {message_feat.shape[1]}")

        # ========== 2. 图像特征提取 ==========
        image_feat = self.image_pre_layer(image)
        print(f"图像特征通道数: {image_feat.shape[1]}")

        # ========== 3. 第一次融合 ==========
        concat_feat1 = torch.cat([image_feat, message_feat], dim=1)
        print(f"第一次拼接通道数: {concat_feat1.shape[1]}")
        fused_feat1 = self.after_concat_layer(concat_feat1)

        # ========== 4. MobileNetV3特征提取 + 通道适配 ==========
        core_feat = self.mobilenetv3_block(fused_feat1)
        print(f"MobileNetV3原始输出通道数: {core_feat.shape[1]}")
        # 关键修复：将8通道转回64通道
        core_feat = self.channel_adapter(core_feat)
        print(f"通道适配后通道数: {core_feat.shape[1]}")

        # ========== 5. 水印特征增强 + 通道适配 ==========
        msg_feat_enhanced = self.mobilenetv3_block(message_feat)
        msg_feat_enhanced = self.channel_adapter(msg_feat_enhanced)
        print(f"增强水印特征通道数: {msg_feat_enhanced.shape[1]}")

        # ========== 6. 最终融合 ==========
        concat_feat2 = torch.cat([core_feat, msg_feat_enhanced], dim=1)
        print(f"第二次拼接通道数: {concat_feat2.shape[1]}")
        final_fused = self.after_concat_layer(concat_feat2)

        # ========== 7. 残差输出 ==========
        output = self.final_layer(final_fused) + image

        return output


# 测试：验证通道数完全匹配，输出维度为[1,3,128,128]
if __name__ == "__main__":
    # 设备配置
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # 初始化编码器
    encoder = Encoder_MP(
        H=128, W=128,
        message_length=64,
        channels=64
    ).to(device)

    # 测试输入：批次大小改为1（核心修改点）
    batch_size = 1  # 从2改为1，确保输出批次维度为1
    test_img = torch.randn(batch_size, 3, 128, 128).to(device)
    test_msg = torch.randn(batch_size, 64).to(device)

    # 前向传播
    try:
        output = encoder(test_img, test_msg)
        print("\n✅ 前向传播成功！")
        print(f"最终输出维度: {output.shape}")
        print(f"使用的MobileNetV3块数量: {encoder.blocks}")
    except RuntimeError as e:
        print(f"\n❌ 运行错误: {e}")