import torch
import torch.nn.functional as F


def jnd(images):
    # 定义卷积核
    G1 = torch.tensor([[0, 0, 0, 0, 0],
                       [1, 3, 8, 3, 1],
                       [0, 0, 0, 0, 0],
                       [-1, -3, -8, -3, -1],
                       [0, 0, 0, 0, 0]], dtype=torch.float32)
    z = torch.zeros_like(G1)
    f1 = torch.stack([G1, z, z, z, G1, z, z, z, G1], dim=-1).view(5, 5, 3, 3)
    g1 = F.conv2d(images, f1, stride=1, padding=2)

    G2 = torch.tensor([[0, 0, 1, 0, 0],
                       [0, 8, 3, 8, 0],
                       [1, 3, 0, -3, -1],
                       [0, 0, -3, 0, 0],
                       [0, 0, -1, 0, 0]], dtype=torch.float32)
    f2 = torch.stack([G2, z, z, z, G2, z, z, z, G2], dim=-1).view(5, 5, 3, 3)
    g2 = F.conv2d(images, f2, stride=1, padding=2) / 16

    G3 = G2.t()
    G4 = G1.t()
    f3 = torch.stack([G3, z, z, z, G3, z, z, z, G3], dim=-1).view(5, 5, 3, 3)
    f4 = torch.stack([G4, z, z, z, G4, z, z, z, G4], dim=-1).view(5, 5, 3, 3)
    g3 = F.conv2d(images, f3, stride=1, padding=2) / 16
    g4 = F.conv2d(images, f4, stride=1, padding=2)

    B = torch.tensor([[1, 1, 1, 1, 1],
                      [1, 2, 2, 2, 1],
                      [1, 2, 0, 2, 1],
                      [1, 2, 2, 2, 1],
                      [1, 1, 1, 1, 1]], dtype=torch.float32)
    f5 = torch.stack([B, z, z, z, B, z, z, z, B], dim=-1).view(5, 5, 3, 3)
    im_bg = F.conv2d(images, f5, stride=1, padding=2) / 32

    im_mg = torch.maximum(torch.maximum(torch.maximum(torch.abs(g1), torch.abs(g2)), torch.abs(g3)), torch.abs(g4))

    lamuda = 1 / 2
    T0 = 17
    Gama = 3 / 128
    im_afa = im_bg * 0.0001 + 0.115
    im_beta = lamuda - im_bg * 0.1
    im_f1 = im_mg * im_afa + im_beta
    im_f2_1 = (im_bg - 127) * Gama + 3
    im_f2_2 = T0 * (1 - (im_bg / 127) ** (1 / 2)) + 3
    im_f2 = torch.where(im_bg > 127, im_f2_1, im_f2_2)
    im_JND = 2 * (im_f1 + 3) + im_f2
    jnd = (im_JND - im_JND.min()) / (im_JND.max() - im_JND.min())
    return jnd
